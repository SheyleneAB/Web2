const setup = () => {
    let pElement=document.getElementById("txtOutput");
    pElement.textContent="Welkom!";
}
window.addEventListener("load", setup);